import { MenuCategory, SpecialOffer } from '../types';

export const RESTAURANT_PHONE = '01043843865';
export const RESTAURANT_WHATSAPP = '201043843865';
export const FACEBOOK_URL = 'https://www.facebook.com/share/19ES6UAYcN/';
export const TIKTOK_URL = 'https://www.tiktok.com/@user2700132902566';
export const RESTAURANT_ADDRESS = 'كورنيش النيل';

export const SPECIAL_OFFERS: SpecialOffer[] = [
  {
    id: 'baraka-tray',
    title: 'صينية البركه ✨',
    img: 'https://files.catbox.moe/ksbh31.png',
    price: 499,
    oldPrice: 620,
    details: [
      'نصف فرخة مشوية على الفحم',
      'ربع كفتة حاتي بلدي',
      'ربع طرب بلدي فاخر',
      'رغيف حواوشي مخصوص'
    ],
    bonusText: 'طبق حلو الكورنيش علينا 🍮',
    deliveryFree: true
  },
  {
    id: 'thursday-offer',
    title: 'عرض الخميس 🌟',
    img: 'https://files.catbox.moe/qzokka.png',
    price: 450,
    oldPrice: 580,
    details: [
      'ربع كباب ضاني فاخر',
      'ربع طرب غنمي',
      '٢ حواوشي ضاني مقرمش',
      'سلطات الحاتي + مخلل فاخر'
    ],
    bonusText: 'طبق حلو الكورنيش علينا 🍮',
    deliveryFree: true
  }
];

export const CAFE_DATA: MenuCategory[] = [
  {
    id: 'hot-drinks',
    title: 'المشروبات الساخنة',
    iconName: 'Coffee',
    img: 'https://i.pinimg.com/736x/33/7e/c0/337ec0bb236800d4153acbf975ff6810.jpg',
    items: [
      { id: 'hd-1', name: 'قهوة تركي', price: 20, description: 'بن برازيلي ممتاز، سادة أو محوج' },
      { id: 'hd-2', name: 'قهوة فرنساوي', price: 25, description: 'قهوة باللبن الغني بالرغوة' },
      { id: 'hd-3', name: 'قهوة بندق', price: 25, description: 'نكهة البندق البلجيكي الفاخر' },
      { id: 'hd-4', name: 'نسكافيه بلاك', price: 20 },
      { id: 'hd-5', name: 'نسكافيه حليب', price: 25 },
      { id: 'hd-6', name: 'إسبريسو', price: 25, description: 'سينجل أو دبل شوت مركز' },
      { id: 'hd-7', name: 'أمريكانو', price: 20 },
      { id: 'hd-8', name: 'كابتشينو', price: 30, description: 'مع رغوة الحليب اللذيذة' },
      { id: 'hd-9', name: 'لاتيه', price: 35 },
      { id: 'hd-10', name: 'مشروب طاقة (باور)', price: 30 },
      { id: 'hd-11', name: 'مشروب أوريو ساخن', price: 30, description: 'بسكويت أوريو ذائب بالحليب' },
      { id: 'hd-12', name: 'هوت شوكليت', price: 30, description: 'شوكولاتة دافئة غنية' },
      { id: 'hd-13', name: 'كاكاو سادة', price: 30 },
      { id: 'hd-14', name: 'كاكاو بالحليب', price: 30 },
      { id: 'hd-15', name: 'شاي مغلي', price: 10, description: 'شاي صعيدي في البراد' },
      { id: 'hd-16', name: 'شاي باكيت', price: 15 },
      { id: 'hd-17', name: 'شاي بالحليب', price: 20 },
      { id: 'hd-18', name: 'ينسون', price: 15 },
      { id: 'hd-19', name: 'زنجبيل سادة', price: 15 },
      { id: 'hd-20', name: 'زنجبيل بالحليب', price: 20 },
      { id: 'hd-21', name: 'قرفة سادة', price: 15 },
      { id: 'hd-22', name: 'قرفة بالحليب', price: 20 },
      { id: 'hd-23', name: 'كركديه ساخن', price: 15, description: 'كركديه أسواني طبيعي' },
      { id: 'hd-24', name: 'هوت سيدر (تفاح ساخن)', price: 25, description: 'عصير تفاح بالقرفة الساخنة' },
      { id: 'hd-25', name: 'ليمون ساخن', price: 15 }
    ]
  },
  {
    id: 'sahlab',
    title: 'السحلب',
    iconName: 'Flame',
    img: 'https://i.pinimg.com/736x/a4/7a/8d/a47a8d0248193210063e9da35480d16b.jpg',
    items: [
      { id: 'sah-1', name: 'سحلب سادة', price: 25, description: 'قوام كريمي غني' },
      { id: 'sah-2', name: 'سحلب مكسرات', price: 30, description: 'محمص بالفول السوداني والسمسم والزبيب وجوز الهند' },
      { id: 'sah-3', name: 'سحلب فواكه', price: 40, description: 'قطع فواكه طازجة مع المكسرات' }
    ]
  },
  {
    id: 'fresh-juices',
    title: 'عصائر فريش',
    iconName: 'GlassWater',
    img: 'https://i.pinimg.com/736x/9a/6a/fb/9a6afb2d0b80febb7ce9d744e1f0c6f3.jpg',
    items: [
      { id: 'fj-1', name: 'موز بالحليب', price: 30 },
      { id: 'fj-2', name: 'بلح بالحليب', price: 30, description: 'بلح سيوي طبيعي غني بالطاقة' },
      { id: 'fj-3', name: 'كيوي', price: 40 },
      { id: 'fj-4', name: 'تفاح', price: 25 },
      { id: 'fj-5', name: 'مانجا', price: 30, description: 'مانجو طبيعي بيور مثلج' },
      { id: 'fj-6', name: 'جوافة', price: 25 },
      { id: 'fj-7', name: 'بطيخ', price: 25 },
      { id: 'fj-8', name: 'ليمون نعناع مثلج', price: 25, description: 'انتعاش طبيعي' },
      { id: 'fj-9', name: 'فراولة', price: 30 },
      { id: 'fj-10', name: 'كانتالوب', price: 25 },
      { id: 'fj-11', name: 'دوم بالحليب', price: 25 },
      { id: 'fj-12', name: 'عصير كوكتيل', price: 30, description: 'طبقات فواكه فريش' },
      { id: 'fj-13', name: 'فرابتشينو موكا', price: 35 },
      { id: 'fj-14', name: 'براوة', price: 25 },
      { id: 'fj-15', name: 'موهيتو', price: 30, description: 'سفن أب مع ليمون ونعناع وسيرب' },
      { id: 'fj-16', name: 'كركديه مثلج', price: 25 }
    ]
  },
  {
    id: 'soda',
    title: 'المشروبات الغازية والمياه',
    iconName: 'Sparkles',
    img: 'https://i.pinimg.com/736x/8e/c8/b6/8ec8b622d6d7135bc9c53e3065e5af08.jpg',
    items: [
      { id: 'sod-1', name: 'كوكاكولا', price: 20 },
      { id: 'sod-2', name: 'فانتا', price: 20 },
      { id: 'sod-3', name: 'سفن أب', price: 20 },
      { id: 'sod-4', name: 'ستينج', price: 20 },
      { id: 'sod-5', name: 'بريل', price: 25 },
      { id: 'sod-6', name: 'فيروز', price: 25 },
      { id: 'sod-7', name: 'كانز صودا', price: 20 },
      { id: 'sod-8', name: 'مياه معدنية صغيرة', price: 10 },
      { id: 'sod-9', name: 'مياه معدنية كبيرة', price: 15 }
    ]
  },
  {
    id: 'milkshake',
    title: 'ميلك شيك',
    iconName: 'Utensils',
    img: 'https://i.pinimg.com/736x/28/b4/c1/28b4c1c8effe5d8d086b3288441e1a90.jpg',
    items: [
      { id: 'ms-1', name: 'ميلك شيك فانيليا', price: 35 },
      { id: 'ms-2', name: 'ميلك شيك مانجا', price: 40 },
      { id: 'ms-3', name: 'ميلك شيك فراولة', price: 40 },
      { id: 'ms-4', name: 'ميلك شيك لوتس', price: 40, description: 'زبدة وبسكويت لوتس بلجيكي' },
      { id: 'ms-5', name: 'آيس بوريو', price: 50, description: 'أيس كريم فانيليا مع بسكويت بوريو غني' }
    ]
  },
  {
    id: 'cocktails',
    title: 'كوكتيلات الكورنيش',
    iconName: 'Wine',
    img: 'https://i.pinimg.com/736x/7f/a9/63/7fa9637a00bf54f1b48edf67ca5e78f0.jpg',
    items: [
      { id: 'ckt-1', name: 'كوكتيل الكورنيش المخصوص', price: 60, description: 'مزيج فاخر من الفواكه الاستوائية والآيس كريم' },
      { id: 'ckt-2', name: 'قنبلة الكورنيش', price: 60, description: 'بسبوسة وكنافة وأرز بلبن وفواكه ومكسرات' },
      { id: 'ckt-3', name: 'سلطة فواكه', price: 50, description: 'فواكه الموسم الطازجة مع عصير المانجو' },
      { id: 'ckt-4', name: 'فخفخينا', price: 35 },
      { id: 'ckt-5', name: 'كشري الكورنيش الحلو', price: 60, description: 'رز بلبن، كنافة، جلاش، لوتس، مكسرات وصوصات' },
      { id: 'ckt-6', name: 'بامبوظة', price: 60 },
      { id: 'ckt-7', name: 'المتدلعة', price: 40, description: 'بسبوسة وكنافة وطبقات قشطة وصوص كراميل' }
    ]
  },
  {
    id: 'ice-cream',
    title: 'الآيس كريم والزبادي',
    iconName: 'IceCream',
    img: 'https://i.pinimg.com/1200x/22/a7/d0/22a7d0ce7700f7169b5990609f5d458f.jpg',
    items: [
      { id: 'ic-1', name: 'آيس كريم ميكس (4 بولة)', price: 25, description: 'اختر نكهاتك المفضلة' },
      { id: 'ic-2', name: 'آيس كريم ميكس (5 بولة)', price: 30 },
      { id: 'ic-3', name: 'آيس كريم بالفواكه', price: 35 },
      { id: 'ic-4', name: 'زبادي خلاط سادة', price: 30, description: 'زبادي طبيعي منعش بالعسل' },
      { id: 'ic-5', name: 'زبادي خلاط بالمانجا', price: 35 },
      { id: 'ic-6', name: 'زبادي خلاط بالفراولة', price: 35 }
    ]
  },
  {
    id: 'rice-pudding',
    title: 'قسم الحلو الفاخر',
    iconName: 'Cookie',
    img: 'https://i.pinimg.com/736x/77/9e/63/779e63849edfa767274a125c1d6f21fd.jpg',
    items: [
      { id: 'rp-1', name: 'رز بلبن سادة', price: 25 },
      { id: 'rp-2', name: 'رز بلبن بسبوسة', price: 35 },
      { id: 'rp-3', name: 'أرز بلبن بالأوريو', price: 30 },
      { id: 'rp-4', name: 'أرز بلبن بالمكسرات', price: 25 },
      { id: 'rp-5', name: 'أرز بلبن باللوتس', price: 35 },
      { id: 'rp-6', name: 'طبق بسبوسة بالمكسرات', price: 25, description: 'سمن بلدي ومكسرات مقرمشة' }
    ]
  },
  {
    id: 'special-corner',
    title: 'الركن المميز',
    iconName: 'Star',
    img: 'https://i.pinimg.com/736x/96/76/23/9676236929ace4bd2a860ba7a8c1e948.jpg',
    items: [
      { id: 'sp-1', name: 'حلبسة (حمص الشام)', price: 25, description: 'حمص الشام بالشطة والليمون والكمون الساخن' },
      { id: 'sp-2', name: 'كنافة بالحليب والقشطة', price: 35, description: 'كنافة طازجة مقرمشة بالقشطة البلدية' },
      { id: 'sp-3', name: 'طاجن أم علي بالقشطة', price: 50, description: 'بالفرن مع مكسرات فاخرة وقشطة بلدي' }
    ]
  }
];

export const RESTAURANT_DATA: MenuCategory[] = [
  {
    id: 'grills',
    title: 'المشويات على الفحم',
    iconName: 'Flame',
    img: 'https://res.cloudinary.com/dbahe7lxz/image/upload/v1788067734/idraaak/gb1rjqcxmtfw8jkdjhi7.png',
    note: 'جميع طلبات المشويات تقدم مع: طحينة + سلطات الحاتى + خبز طازج',
    items: [
      {
        id: 'gr-1',
        name: 'كباب ضاني بلدي',
        price: [
          { portion: 'نصف كيلو', price: 450 },
          { portion: 'ربع كيلو', price: 225 }
        ],
        rawPrice: 'نصف: 450 | ربع: 225',
        description: 'لحم ضاني طازج مشوي على الفحم بتتبيلة الحاتي الخاصة'
      },
      {
        id: 'gr-2',
        name: 'كباب عجالي ممتاز',
        price: [
          { portion: 'كيلو', price: 799 },
          { portion: 'نصف كيلو', price: 400 },
          { portion: 'ربع كيلو', price: 200 }
        ],
        rawPrice: 'كيلو: 799 | نصف: 400 | ربع: 200'
      },
      {
        id: 'gr-3',
        name: 'كفتة الحاتي البلدي',
        price: [
          { portion: 'كيلو', price: 600 },
          { portion: 'نصف كيلو', price: 300 },
          { portion: 'ربع كيلو', price: 160 }
        ],
        rawPrice: 'كيلو: 600 | نصف: 300 | ربع: 160',
        description: 'كفتة مشوية على الفحم بأعلى جودة لحم بلدي'
      },
      {
        id: 'gr-4',
        name: 'طرب بلدي أصلي',
        price: [
          { portion: 'كيلو', price: 700 },
          { portion: 'نصف كيلو', price: 350 },
          { portion: 'ربع كيلو', price: 180 }
        ],
        rawPrice: 'كيلو: 700 | نصف: 350 | ربع: 180',
        description: 'طرب ملفوف بمنديل الضاني البلدي المتبل'
      },
      {
        id: 'gr-5',
        name: 'مشكل (كباب + سلاش + كفتة)',
        price: [
          { portion: 'كيلو', price: 700 },
          { portion: 'نصف كيلو', price: 350 },
          { portion: 'ربع كيلو', price: 180 }
        ],
        rawPrice: 'كيلو: 700 | نصف: 350 | ربع: 180'
      },
      {
        id: 'gr-6',
        name: 'دجاج مشوي على الفحم',
        price: [
          { portion: 'فرخة كاملة', price: 320 },
          { portion: 'نصف فرخة', price: 160 },
          { portion: 'ربع فرخة', price: 85 }
        ],
        rawPrice: 'فرخة: 320 | نصف: 160 | ربع: 85'
      },
      {
        id: 'gr-7',
        name: 'شيش طاووق متبل',
        price: [
          { portion: 'كيلو', price: 400 },
          { portion: 'نصف كيلو', price: 200 },
          { portion: 'ربع كيلو', price: 110 }
        ],
        rawPrice: 'كيلو: 400 | نصف: 200 | ربع: 110'
      },
      {
        id: 'gr-8',
        name: 'سجق بلدي مشوي ع الفحم',
        price: [
          { portion: 'كيلو', price: 450 },
          { portion: 'نصف كيلو', price: 230 },
          { portion: 'ربع كيلو', price: 120 }
        ],
        rawPrice: 'كيلو: 450 | نصف: 230 | ربع: 120'
      }
    ]
  },
  {
    id: 'meals',
    title: 'وجبات الكورنيش',
    iconName: 'Utensils',
    img: 'https://res.cloudinary.com/dbahe7lxz/image/upload/v1788067859/idraaak/o9ipv6yyack5sx0eak3u.png',
    note: 'وجبات الكورنيش تقدم مع: أرز بسمتي + سلطات الحاتى + خبز',
    items: [
      {
        id: 'ml-1',
        name: 'وجبة التوفير',
        price: 160,
        description: 'ربع دجاجة + ثُمن كفتة + أرز بسمتي + سلطات وعيش'
      },
      {
        id: 'ml-2',
        name: 'وجبة الأكيلة',
        price: 199,
        description: 'ثُمن كفتة + ثُمن سجق + 2 رغيف حواوشي + أرز وسلطات'
      },
      {
        id: 'ml-3',
        name: 'وجبة الميكس',
        price: 240,
        description: 'ربع كفتة + ربع دجاجة + أرز بسمتي + سلطات وخبز'
      },
      {
        id: 'ml-4',
        name: 'وجبة الكورنيش الخاصة',
        price: 360,
        description: 'نصف دجاجة + ربع كباب + أرز بسمتي مبهر + سلطات الحاتي'
      },
      {
        id: 'ml-5',
        name: 'وجبة السوبر ليدر',
        price: 399,
        description: 'ربع شيش + ربع سجق + ربع طرب + لتر بيبسي هدية'
      }
    ]
  },
  {
    id: 'trays',
    title: 'صواني الكورنيش الملكية',
    iconName: 'Crown',
    img: 'https://files.catbox.moe/cwnmsi.png',
    items: [
      {
        id: 'tr-1',
        name: 'صينية المزاجنجية',
        price: 450,
        description: 'نصف دجاجة، ربع كفتة، ثُمن طرب، 2 حواوشي، لتر بيبسي + أرز وسلطات'
      },
      {
        id: 'tr-2',
        name: 'صينية الكبار',
        price: 550,
        description: 'ربع شيش، ثُمن سجق، ربع كفتة، ربع كباب، 2 حواوشي، لتر بيبسي'
      },
      {
        id: 'tr-3',
        name: 'صينية المغفلقين',
        price: 559,
        description: 'نصف كفتة، ثُمن طرب، نصف دجاجة، 2 حواوشي، سلطات الحاتى، أرز، لتر بيبسي'
      },
      {
        id: 'tr-4',
        name: 'صينية المقاول العملاقة',
        price: 1199,
        description: 'نصف كباب، نصف طرب، نصف شيش، نصف كفتة، 2 لتر بيبسى + أرز بسمتي وسلطات'
      },
      {
        id: 'tr-5',
        name: 'صينية العريس الملكية (حجز مسبق)',
        price: 1599,
        description: 'نصف كباب، ربع طرب، نصف كفتة، 4 فرد حمام بالفريك، أرز، سلطات الحاتى، 4 ريد بول'
      }
    ]
  },
  {
    id: 'rizo',
    title: 'الريزو والأرز البسمتي',
    iconName: 'Sparkles',
    img: 'https://files.catbox.moe/lcz9gs.png',
    items: [
      { id: 'rz-1', name: 'أرز بسمتي بقطع الكبدة الإسكندراني', price: 60 },
      { id: 'rz-2', name: 'أرز بسمتي بقطع السجق البلدي', price: 60 },
      { id: 'rz-3', name: 'أرز بسمتي بكفتة جريل', price: 70 }
    ]
  },
  {
    id: 'grill-pan',
    title: 'أطباق الجريل الساخنة',
    iconName: 'Flame',
    img: 'https://files.catbox.moe/l1z9vv.png',
    note: 'تقدم مع سلطات الحاتي + عيش بلدي ساخن',
    items: [
      { id: 'gp-1', name: 'طلب كبدة إسكندراني مخصوص', price: 75 },
      { id: 'gp-2', name: 'طلب سجق بلدي شرقي', price: 80 },
      { id: 'gp-3', name: 'طلب كفتة جريل صوص خفيف', price: 90 },
      { id: 'gp-4', name: 'طبق ميكس جريل الكورنيش', price: 100, description: 'كبدة + سجق + كفتة جريل بتوابلنا السرية' }
    ]
  },
  {
    id: 'sandwiches',
    title: 'السندوتشات والحواوشي',
    iconName: 'Beef',
    img: 'https://files.catbox.moe/1pxo9i.png',
    items: [
      { id: 'sw-1', name: 'ساندوتش كبدة اسكندراني', price: 25 },
      { id: 'sw-2', name: 'ساندوتش سجق اسكندرانى', price: 25 },
      { id: 'sw-3', name: 'سوبر الكورنيش مخصوص', price: 35 },
      { id: 'sw-4', name: 'حواوشي بلدى على الفحم', price: 30, description: 'لحم بلدي متبل بالبصل والفلفل' },
      { id: 'sw-5', name: 'حواوشي فراخ مقرمش', price: 40 },
      { id: 'sw-6', name: 'حواوشي ضانى فاخر', price: 45, description: 'لحم ضاني دسم مع تتبيلة مميزة' },
      { id: 'sw-7', name: 'ساندوتش بانيه كرسبي', price: 20 },
      { id: 'sw-8', name: 'ساندوتش استربس مقرمش', price: 35 },
      { id: 'sw-9', name: 'ساندوتش كفتة جريل', price: 35 },
      { id: 'sw-10', name: 'ساندوتش كفته بلدى ع الفحم', price: 50 },
      { id: 'sw-11', name: 'ساندوتش سجق ع الفحم', price: 35 }
    ]
  },
  {
    id: 'desserts-rest',
    title: 'الحلو بعد الأكلة',
    iconName: 'Cookie',
    img: 'https://files.catbox.moe/lsoigf.png',
    items: [
      { id: 'dr-1', name: 'رز بلبن فرن', price: 25 },
      { id: 'dr-2', name: 'رز بلبن بسبوسه', price: 35 },
      { id: 'dr-3', name: 'كشرى الكورنيش الحلو', price: 60 },
      { id: 'dr-4', name: 'قنبلة الكورنيش', price: 60 },
      { id: 'dr-5', name: 'سلطة فواكه فرش', price: 50 },
      { id: 'dr-6', name: 'طاجن أم علي بالقشطة', price: 35 }
    ]
  },
  {
    id: 'additions',
    title: 'المقبلات والاضافات',
    iconName: 'PlusCircle',
    img: 'https://files.catbox.moe/fep5l4.png',
    items: [
      { id: 'ad-1', name: 'طبق مخلل مشكل بلدي', price: 10 },
      { id: 'ad-2', name: 'طحينة الحاتى السميكة', price: 15 },
      { id: 'ad-3', name: 'سلطة الحاتى الخضراء بالدقة', price: 10 },
      { id: 'ad-4', name: 'طلب عيش بلدي طازج', price: 5 }
    ]
  }
];
