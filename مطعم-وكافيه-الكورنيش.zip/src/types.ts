export type MenuMode = 'cafe' | 'restaurant';

export interface PricePortion {
  portion: string;
  price: number;
}

export interface MenuItem {
  id: string;
  name: string;
  description?: string;
  price: number | string | PricePortion[];
  rawPrice?: string | number;
  tags?: string[];
  popular?: boolean;
}

export interface MenuCategory {
  id: string;
  title: string;
  iconName: string;
  img: string;
  note?: string;
  items: MenuItem[];
}

export interface SpecialOffer {
  id: string;
  title: string;
  img: string;
  price: number;
  oldPrice?: number;
  details: string[];
  bonusText?: string;
  deliveryFree?: boolean;
}

export interface CartItem {
  id: string;
  name: string;
  portionLabel?: string;
  price: number;
  quantity: number;
  categoryTitle: string;
}
