import React from 'react';
import { Coffee, Utensils, MapPin, Phone, Star, Heart } from 'lucide-react';
import {
  RESTAURANT_PHONE,
  RESTAURANT_WHATSAPP,
  RESTAURANT_ADDRESS,
  FACEBOOK_URL,
  TIKTOK_URL
} from '../data/menuData';

export const Footer: React.FC = () => {
  return (
    <footer className="relative mt-20 border-t border-white/10 bg-[#07070b] pt-12 pb-24 text-center">
      <div className="max-w-4xl mx-auto px-4">
        {/* Working Hours Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 max-w-2xl mx-auto mb-8">
          <div className="p-5 rounded-2xl bg-[#111116] border border-yellow-400/30 shadow-lg text-center">
            <div className="flex items-center justify-center gap-2 text-yellow-400 font-cairo font-black text-lg mb-1">
              <Coffee className="w-5 h-5 stroke-[2.2]" />
              <h4>مواعيد الكافيه</h4>
            </div>
            <p className="text-gray-300 text-sm font-medium">
              يومياً من <strong className="text-white">9:00 صباحاً</strong> إلى{' '}
              <strong className="text-white">2:00 صباحاً</strong>
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-[#111116] border border-red-500/30 shadow-lg text-center">
            <div className="flex items-center justify-center gap-2 text-red-400 font-cairo font-black text-lg mb-1">
              <Utensils className="w-5 h-5 stroke-[2.2]" />
              <h4>مواعيد المطعم والمشويات</h4>
            </div>
            <p className="text-gray-300 text-sm font-medium">
              يومياً من <strong className="text-white">2:00 ظهراً</strong> إلى{' '}
              <strong className="text-white">1:00 بعد منتصف الليل</strong>
            </p>
          </div>
        </div>

        {/* Contact and Info */}
        <div className="space-y-2 mb-6">
          <p className="text-gray-300 font-bold text-base flex items-center justify-center gap-2">
            <span>العنوان: {RESTAURANT_ADDRESS}</span>
            <MapPin className="w-4 h-4 text-red-500" />
          </p>

          <p className="text-yellow-400 font-bold text-base flex items-center justify-center gap-2">
            <span>للطلب والاستفسار وخدمة التوصيل:</span>
            <a
              href={`tel:${RESTAURANT_PHONE}`}
              className="underline font-cairo font-black tracking-wider text-lg"
              dir="ltr"
            >
              {RESTAURANT_PHONE}
            </a>
            <Phone className="w-4 h-4 text-yellow-400" />
          </p>

          <p className="text-gray-400 text-xs sm:text-sm flex items-center justify-center gap-1.5 pt-2">
            <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
            <span>تابعونا على وسائل التواصل للاستمتاع بالعروض الأسبوعية الحصرية</span>
            <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
          </p>
        </div>

        {/* Social Links Row */}
        <div className="flex items-center justify-center gap-3 mb-8">
          <a
            href={`https://wa.me/${RESTAURANT_WHATSAPP}`}
            target="_blank"
            rel="noopener noreferrer"
            className="px-4 py-2 rounded-xl bg-[#25D366]/20 hover:bg-[#25D366] text-[#25D366] hover:text-white border border-[#25D366]/40 text-xs font-bold transition-all shadow"
          >
            واتساب
          </a>

          <a
            href={FACEBOOK_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="px-4 py-2 rounded-xl bg-[#1877F2]/20 hover:bg-[#1877F2] text-[#1877F2] hover:text-white border border-[#1877F2]/40 text-xs font-bold transition-all shadow"
          >
            فيسبوك
          </a>

          <a
            href={TIKTOK_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white border border-white/20 text-xs font-bold transition-all shadow"
          >
            تيك توك
          </a>
        </div>

        {/* Copyright */}
        <div className="border-t border-white/5 pt-6 text-xs text-gray-500 font-medium">
          <p>© 2026 مطعم وكافيه الكورنيش. جميع الحقوق محفوظة.</p>
        </div>
      </div>
    </footer>
  );
};
