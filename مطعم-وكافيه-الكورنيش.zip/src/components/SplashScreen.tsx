import React from 'react';
import { Coffee, Utensils, Flame, Tags, Volume2, VolumeX, Sparkles } from 'lucide-react';
import { MenuMode } from '../types';
import { playTapSound, toggleMute } from '../utils/audio';

interface SplashScreenProps {
  onEnter: (mode: MenuMode) => void;
  onOpenOffers: () => void;
  isMuted: boolean;
  onToggleSound: () => void;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({
  onEnter,
  onOpenOffers,
  isMuted,
  onToggleSound
}) => {
  const handleSelect = (mode: MenuMode) => {
    playTapSound(700, 0.12);
    onEnter(mode);
  };

  return (
    <div
      id="splash-screen"
      className="fixed inset-0 z-50 flex items-center justify-center overflow-hidden bg-[#050507]"
    >
      {/* Ambient background with parallax scale */}
      <div
        className="absolute inset-0 bg-cover bg-center opacity-20 scale-105 transition-transform duration-1000"
        style={{
          backgroundImage: `url('https://cdn.phototourl.com/free/2026-06-14-6a988a66-859b-4e93-99ef-c47b09573c97.jpg')`,
        }}
      />

      {/* Atmospheric lighting gradients */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_0%,rgba(0,0,0,0.85)_80%)]" />
      <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-transparent to-[#050507]" />

      {/* Radiant golden central glow */}
      <div className="absolute w-96 h-96 rounded-full bg-[#FADB5F] opacity-15 blur-[120px] pointer-events-none" />

      {/* Top action controls: Sound */}
      <div className="absolute top-5 right-5 z-20 flex items-center gap-3">
        <button
          onClick={() => {
            toggleMute();
            onToggleSound();
          }}
          className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/10 hover:bg-white/20 text-xs font-semibold backdrop-blur-md border border-white/10 text-yellow-300 transition-all cursor-pointer"
          title="تفعيل أو كتم الصوت"
        >
          {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
          <span>{isMuted ? 'صوت مكتوم' : 'الصوت يعمل'}</span>
        </button>
      </div>

      {/* Content Container */}
      <div className="relative z-10 w-full max-w-xl px-5 py-8 text-center">
        {/* Subtle decorative badge */}
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-yellow-500/15 border border-yellow-400/30 text-yellow-300 text-sm font-semibold mb-4 tracking-wide shadow-lg shadow-yellow-500/10">
          <Sparkles className="w-4 h-4 text-yellow-400 animate-spin" style={{ animationDuration: '4s' }} />
          <span>أهلاً بكم في الصرح الفاخر على كورنيش النيل</span>
        </div>

        {/* Cinematic Title */}
        <h1 className="font-amiri text-5xl sm:text-7xl font-black text-transparent bg-clip-text bg-gradient-to-r from-[#D4A017] via-[#FFF8DC] to-[#FADB5F] leading-tight drop-shadow-[0_4px_25px_rgba(250,219,95,0.45)]">
          مطعم وكافيه
          <br />
          <span className="text-yellow-400 tracking-wider">الكورنيش</span>
        </h1>

        {/* Laser divider line */}
        <div className="w-48 sm:w-64 h-[2px] mx-auto my-6 bg-gradient-to-r from-transparent via-[#FADB5F] to-transparent shadow-[0_0_15px_#FADB5F]" />

        <p className="text-gray-300 text-sm sm:text-base mb-8 max-w-md mx-auto leading-relaxed">
          اختر القسم الذي ترغب في تصفحه أو استكشف أقوى عروض الافتتاح المتاحة حالياً
        </p>

        {/* Main Selection Buttons Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 max-w-lg mx-auto">
          {/* Cafe Entry Button */}
          <button
            onClick={() => handleSelect('cafe')}
            className="btn-legendary-gold group relative min-h-[85px] sm:min-h-[95px] rounded-2xl p-4 flex items-center justify-between overflow-hidden cursor-pointer cursor-pointer shadow-xl text-right"
          >
            <div className="flex items-center gap-3.5">
              <div className="w-13 h-13 rounded-xl bg-black/15 flex items-center justify-center border border-black/10 group-hover:scale-110 transition-transform">
                <Coffee className="w-7 h-7 text-black stroke-[2.2]" />
              </div>
              <div>
                <span className="block font-cairo font-black text-xl text-black">كافيه الكورنيش</span>
                <span className="block text-xs font-semibold text-neutral-800">مشروبات • عصائر • حلويات</span>
              </div>
            </div>
            <div className="text-black/60 group-hover:translate-x-[-4px] transition-transform text-lg font-bold">
              ←
            </div>
          </button>

          {/* Restaurant Entry Button */}
          <button
            onClick={() => handleSelect('restaurant')}
            className="btn-legendary-crimson group relative min-h-[85px] sm:min-h-[95px] rounded-2xl p-4 flex items-center justify-between overflow-hidden cursor-pointer shadow-xl text-right"
          >
            <div className="flex items-center gap-3.5">
              <div className="w-13 h-13 rounded-xl bg-black/20 flex items-center justify-center border border-white/10 group-hover:scale-110 transition-transform">
                <Utensils className="w-7 h-7 text-white stroke-[2.2]" />
              </div>
              <div>
                <span className="block font-cairo font-black text-xl text-white">مطعم الكورنيش</span>
                <span className="block text-xs font-semibold text-red-100">مشويات • وجبات • صواني</span>
              </div>
            </div>
            <div className="text-white/70 group-hover:translate-x-[-4px] transition-transform text-lg font-bold">
              ←
            </div>
          </button>
        </div>

        {/* Grand Opening Offers Button - Legendary Pulse */}
        <div className="mt-4 max-w-lg mx-auto">
          <button
            onClick={() => {
              playTapSound(800, 0.15);
              onOpenOffers();
            }}
            className="btn-legendary-offers animate-super-pulse w-full min-h-[75px] rounded-2xl p-4 flex items-center justify-center gap-3.5 cursor-pointer text-white shadow-2xl transition-all"
          >
            <Flame className="w-7 h-7 text-yellow-300 drop-shadow-[0_0_10px_rgba(250,219,95,0.8)] animate-bounce" />
            <div className="text-center">
              <span className="block font-cairo font-black text-2xl tracking-wide text-white drop-shadow">
                🔥 عروووووض الافتتاح الكبرى 🔥
              </span>
              <span className="text-xs font-bold text-yellow-300 tracking-wider">
                صواني التوفير + حلو مجاني + ديليفري لحد باب البيت
              </span>
            </div>
            <Tags className="w-6 h-6 text-yellow-300 drop-shadow" />
          </button>
        </div>

        {/* Footer info badge */}
        <div className="mt-8 text-xs text-gray-400 font-medium">
          متاح التوصيل لجميع المناطق 🛵 • هاتف وواتساب: <span className="text-yellow-400 font-bold" dir="ltr">01043843865</span>
        </div>
      </div>
    </div>
  );
};
