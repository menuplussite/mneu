import React from 'react';
import { X, Flame, Bike, Gift, Phone, MessageCircle, ShoppingBag, Plus } from 'lucide-react';
import { SPECIAL_OFFERS, RESTAURANT_PHONE, RESTAURANT_WHATSAPP } from '../data/menuData';
import { SpecialOffer } from '../types';
import { playTapSound, playSuccessSound } from '../utils/audio';

interface OffersModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddToCart?: (offer: SpecialOffer) => void;
}

export const OffersModal: React.FC<OffersModalProps> = ({
  isOpen,
  onClose,
  onAddToCart
}) => {
  if (!isOpen) return null;

  const handleWhatsAppOrder = (offer: SpecialOffer) => {
    playTapSound(750, 0.1);
    const text = encodeURIComponent(
      `السلام عليكم، أرغب في طلب ${offer.title} بسعر ${offer.price} جنيه من عروض الافتتاح لمطعم وكافيه الكورنيش.`
    );
    window.open(`https://wa.me/${RESTAURANT_WHATSAPP}?text=${text}`, '_blank');
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-md overflow-y-auto animate-fadeIn"
      onClick={(e) => {
        if (e.target === e.currentTarget) {
          playTapSound(400, 0.08);
          onClose();
        }
      }}
    >
      <div className="relative w-full max-w-lg bg-[#111116] border-2 border-yellow-400/40 rounded-3xl overflow-hidden shadow-[0_25px_60px_rgba(0,0,0,0.9),0_0_35px_rgba(250,219,95,0.15)] my-auto max-h-[90vh] flex flex-col">
        {/* Close Button */}
        <button
          onClick={() => {
            playTapSound(400, 0.08);
            onClose();
          }}
          className="absolute top-4 left-4 z-30 w-10 h-10 rounded-full bg-black/70 border border-white/20 text-gray-300 hover:text-white hover:bg-red-600/80 flex items-center justify-center transition-all cursor-pointer shadow-lg"
          aria-label="إغلاق"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="pt-6 pb-4 px-6 text-center border-b border-white/10 bg-gradient-to-b from-yellow-500/10 to-transparent">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-red-600/20 border border-red-500/30 text-red-400 text-xs font-bold mb-2">
            <Flame className="w-3.5 h-3.5 text-red-400 animate-pulse" />
            <span>لفترة محدودة فقط بمناسبة الافتتاح</span>
          </div>

          <h2 className="font-amiri text-3xl sm:text-4xl font-black text-yellow-400 drop-shadow-[0_0_15px_rgba(250,219,95,0.4)]">
            عروض الافتتاح الكبرى 🔥
          </h2>
          <p className="text-gray-300 text-xs sm:text-sm mt-1">
            صواني الكورنيش الملكية مع هدية حلو وتوصيل مجاني
          </p>
        </div>

        {/* Offers List (Scrollable) */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-6 divide-y divide-yellow-500/20">
          {SPECIAL_OFFERS.map((offer, idx) => (
            <div key={offer.id} className={`${idx > 0 ? 'pt-6' : ''}`}>
              {/* Offer Card */}
              <div className="bg-[#181820] border border-white/10 rounded-2xl p-4 transition-all hover:border-yellow-400/40">
                {/* Image */}
                <div className="relative w-full h-44 sm:h-52 rounded-xl overflow-hidden bg-black/40 mb-4 flex items-center justify-center">
                  <img
                    src={offer.img}
                    alt={offer.title}
                    className="w-full h-full object-contain p-2 filter drop-shadow-[0_8px_16px_rgba(0,0,0,0.6)]"
                    loading="lazy"
                  />
                  {offer.oldPrice && (
                    <div className="absolute top-2 right-2 px-2.5 py-1 rounded-lg bg-red-600 text-white text-xs font-bold shadow-md">
                      خصم {offer.oldPrice - offer.price} ج
                    </div>
                  )}
                </div>

                {/* Offer Details */}
                <div className="text-center">
                  <h3 className="font-amiri font-bold text-2xl text-yellow-400 mb-2">
                    {offer.title}
                  </h3>

                  <ul className="text-sm text-gray-200 space-y-1.5 font-tajawal font-medium mb-3">
                    {offer.details.map((detail, dIdx) => (
                      <li key={dIdx} className="flex items-center justify-center gap-1.5">
                        <span className="w-1.5 h-1.5 rounded-full bg-yellow-400" />
                        <span>{detail}</span>
                      </li>
                    ))}
                  </ul>

                  {/* Highlights */}
                  {offer.bonusText && (
                    <div className="inline-flex items-center gap-1.5 text-yellow-300 font-bold text-sm bg-yellow-400/15 border border-yellow-400/30 px-3 py-1 rounded-lg my-1 shadow-sm">
                      <Gift className="w-4 h-4 text-yellow-400" />
                      <span>{offer.bonusText}</span>
                    </div>
                  )}

                  {offer.deliveryFree && (
                    <div className="flex items-center justify-center gap-1.5 text-emerald-400 font-bold text-sm mt-1">
                      <Bike className="w-4 h-4 text-emerald-400 animate-bounce" />
                      <span>ديليفري مجاني لحد باب البيت</span>
                    </div>
                  )}

                  {/* Price Tag */}
                  <div className="my-3 flex items-center justify-center gap-3">
                    {offer.oldPrice && (
                      <span className="text-gray-400 line-through text-sm font-bold">
                        {offer.oldPrice} ج
                      </span>
                    )}
                    <div className="px-5 py-2 rounded-xl bg-gradient-to-r from-[#FADB5F] to-[#D4A017] text-black font-cairo font-black text-xl shadow-lg shadow-yellow-500/20">
                      {offer.price} جنيه فقط
                    </div>
                  </div>

                  {/* Action Buttons for this Offer */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-4">
                    <button
                      onClick={() => handleWhatsAppOrder(offer)}
                      className="w-full py-2.5 px-3 rounded-xl bg-[#25D366] hover:bg-[#20bd5a] text-white font-cairo font-bold text-sm flex items-center justify-center gap-2 shadow-lg shadow-green-500/20 transition-all cursor-pointer"
                    >
                      <MessageCircle className="w-4 h-4" />
                      <span>اطلب العرض عبر واتساب</span>
                    </button>

                    {onAddToCart && (
                      <button
                        onClick={() => {
                          playSuccessSound();
                          onAddToCart(offer);
                        }}
                        className="w-full py-2.5 px-3 rounded-xl bg-yellow-500/20 hover:bg-yellow-500/30 border border-yellow-400/50 text-yellow-300 font-cairo font-bold text-sm flex items-center justify-center gap-2 transition-all cursor-pointer"
                      >
                        <Plus className="w-4 h-4 text-yellow-400" />
                        <span>إضافة للسلة</span>
                      </button>
                    )}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Modal Bottom Call Actions */}
        <div className="p-4 bg-[#0c0c10] border-t border-white/10 flex flex-col sm:flex-row gap-2.5">
          <a
            href={`https://wa.me/${RESTAURANT_WHATSAPP}?text=${encodeURIComponent(
              'السلام عليكم، أرغب في الاستفسار عن عروض مطعم وكافيه الكورنيش'
            )}`}
            target="_blank"
            rel="noopener noreferrer"
            onClick={() => playTapSound(700, 0.08)}
            className="flex-1 py-3 px-4 rounded-xl bg-[#25D366] hover:bg-[#1fa952] text-white font-cairo font-black text-base flex items-center justify-center gap-2 shadow-lg transition-all"
          >
            <MessageCircle className="w-5 h-5" />
            <span>طلب فوري واتساب: {RESTAURANT_PHONE}</span>
          </a>

          <a
            href={`tel:${RESTAURANT_PHONE}`}
            onClick={() => playTapSound(600, 0.08)}
            className="sm:w-auto py-3 px-5 rounded-xl bg-black border border-yellow-400 text-yellow-400 hover:bg-yellow-400 hover:text-black font-cairo font-bold text-sm flex items-center justify-center gap-2 transition-all"
          >
            <Phone className="w-4 h-4" />
            <span>اتصال مباشر</span>
          </a>
        </div>
      </div>
    </div>
  );
};
