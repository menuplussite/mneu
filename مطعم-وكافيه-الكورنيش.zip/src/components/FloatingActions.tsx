import React, { useState, useEffect } from 'react';
import {
  ChevronUp,
  ChevronDown,
  MessageCircle,
  Phone,
  ShoppingBag,
  Volume2,
  VolumeX,
  Share2
} from 'lucide-react';
import { RESTAURANT_PHONE, RESTAURANT_WHATSAPP } from '../data/menuData';
import { playTapSound } from '../utils/audio';

interface FloatingActionsProps {
  cartCount: number;
  cartTotal: number;
  onOpenCart: () => void;
  isMuted: boolean;
  onToggleSound: () => void;
}

export const FloatingActions: React.FC<FloatingActionsProps> = ({
  cartCount,
  cartTotal,
  onOpenCart,
  isMuted,
  onToggleSound
}) => {
  const [showScrollTop, setShowScrollTop] = useState(false);
  const [showScrollBottom, setShowScrollBottom] = useState(true);

  useEffect(() => {
    const handleScroll = () => {
      const scrollY = window.scrollY;
      const maxScroll = document.documentElement.scrollHeight - window.innerHeight;

      setShowScrollTop(scrollY > 300);
      setShowScrollBottom(scrollY < maxScroll - 300);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToTop = () => {
    playTapSound(700, 0.08);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const scrollToBottom = () => {
    playTapSound(600, 0.08);
    window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' });
  };

  const handleShare = async () => {
    playTapSound(600, 0.08);
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'مطعم وكافيه الكورنيش',
          text: 'شاهد منيو مطعم وكافيه الكورنيش وأقوى عروض الافتتاح!',
          url: window.location.href,
        });
      } catch {
        // ignore share cancellation
      }
    } else {
      navigator.clipboard.writeText(window.location.href);
      alert('تم نسخ رابط المنيو بنجاح!');
    }
  };

  return (
    <>
      {/* Floating Cart Button (Bottom Center / Left) */}
      {cartCount > 0 && (
        <div className="fixed bottom-20 sm:bottom-6 left-1/2 -translate-x-1/2 z-40 animate-bounce">
          <button
            onClick={() => {
              playTapSound(800, 0.1);
              onOpenCart();
            }}
            className="btn-legendary-gold flex items-center gap-3 px-5 py-3 rounded-full shadow-2xl border border-yellow-300/60 cursor-pointer"
          >
            <div className="relative">
              <ShoppingBag className="w-5 h-5 text-black stroke-[2.5]" />
              <span className="absolute -top-2 -right-2 bg-red-600 text-white text-[11px] font-black w-5 h-5 rounded-full flex items-center justify-center shadow">
                {cartCount}
              </span>
            </div>
            <div className="text-right">
              <div className="font-cairo font-black text-sm text-black leading-none">عرض السلة</div>
              <div className="text-xs font-bold text-neutral-800 leading-tight">{cartTotal} ج</div>
            </div>
          </button>
        </div>
      )}

      {/* Floating Left: Scroll Arrows + Sound Toggle */}
      <div className="fixed left-4 bottom-4 z-40 flex flex-col gap-2">
        {showScrollTop && (
          <button
            onClick={scrollToTop}
            className="w-10 h-10 rounded-full bg-black/80 hover:bg-yellow-400 hover:text-black text-yellow-400 border border-yellow-400/50 flex items-center justify-center backdrop-blur-md shadow-xl transition-all cursor-pointer hover:scale-110 active:scale-90"
            title="الصعود لأعلى"
          >
            <ChevronUp className="w-5 h-5" />
          </button>
        )}

        {showScrollBottom && (
          <button
            onClick={scrollToBottom}
            className="w-10 h-10 rounded-full bg-black/80 hover:bg-yellow-400 hover:text-black text-yellow-400 border border-yellow-400/50 flex items-center justify-center backdrop-blur-md shadow-xl transition-all cursor-pointer hover:scale-110 active:scale-90"
            title="النزول لأسفل"
          >
            <ChevronDown className="w-5 h-5" />
          </button>
        )}

        <button
          onClick={() => {
            playTapSound(500, 0.06);
            onToggleSound();
          }}
          className="w-10 h-10 rounded-full bg-black/80 hover:bg-white/20 text-gray-300 border border-white/20 flex items-center justify-center backdrop-blur-md shadow-xl transition-all cursor-pointer hover:scale-105 active:scale-90"
          title={isMuted ? 'تشغيل أصوات التفاعل' : 'كتم أصوات التفاعل'}
        >
          {isMuted ? <VolumeX className="w-4 h-4 text-red-400" /> : <Volume2 className="w-4 h-4 text-yellow-400" />}
        </button>
      </div>

      {/* Floating Right: Social & Direct WhatsApp/Phone Bar */}
      <div className="fixed right-4 bottom-4 z-40 flex items-center gap-2 p-1.5 rounded-2xl bg-black/80 backdrop-blur-xl border border-white/15 shadow-2xl">
        <a
          href={`https://wa.me/${RESTAURANT_WHATSAPP}`}
          target="_blank"
          rel="noopener noreferrer"
          onClick={() => playTapSound(700, 0.08)}
          className="w-10 h-10 rounded-xl bg-[#25D366] hover:bg-[#20bd5a] text-white flex items-center justify-center shadow-lg hover:scale-110 active:scale-95 transition-all"
          title="محادثة واتساب"
        >
          <MessageCircle className="w-5 h-5 fill-current" />
        </a>

        <a
          href={`tel:${RESTAURANT_PHONE}`}
          onClick={() => playTapSound(600, 0.08)}
          className="w-10 h-10 rounded-xl bg-gradient-to-r from-red-600 to-amber-600 text-white flex items-center justify-center shadow-lg hover:scale-110 active:scale-95 transition-all"
          title="اتصال هاتفي"
        >
          <Phone className="w-5 h-5" />
        </a>

        <button
          onClick={handleShare}
          className="w-10 h-10 rounded-xl bg-white/10 hover:bg-white/20 text-gray-200 flex items-center justify-center hover:scale-110 active:scale-95 transition-all cursor-pointer"
          title="مشاركة المنيو"
        >
          <Share2 className="w-4 h-4" />
        </button>
      </div>
    </>
  );
};
