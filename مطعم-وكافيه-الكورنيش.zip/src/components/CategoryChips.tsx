import React from 'react';
import { MenuCategory, MenuMode } from '../types';
import {
  Coffee,
  Flame,
  GlassWater,
  Sparkles,
  Utensils,
  Wine,
  IceCream,
  Cookie,
  Star,
  Crown,
  Beef,
  PlusCircle,
  LucideIcon
} from 'lucide-react';
import { playTapSound } from '../utils/audio';

const ICON_MAP: Record<string, LucideIcon> = {
  Coffee,
  Flame,
  GlassWater,
  Sparkles,
  Utensils,
  Wine,
  IceCream,
  Cookie,
  Star,
  Crown,
  Beef,
  PlusCircle
};

interface CategoryChipsProps {
  categories: MenuCategory[];
  activeCategoryId: string | null;
  onSelectCategory: (id: string) => void;
  mode: MenuMode;
}

export const CategoryChips: React.FC<CategoryChipsProps> = ({
  categories,
  activeCategoryId,
  onSelectCategory,
  mode
}) => {
  const isCafe = mode === 'cafe';

  return (
    <div className="sticky top-0 z-30 py-3 mb-6 bg-[#050507]/90 backdrop-blur-xl border-b border-white/10 shadow-lg">
      <div className="max-w-6xl mx-auto px-3">
        <div className="flex items-center gap-2 overflow-x-auto hide-scrollbar py-1">
          {categories.map((cat) => {
            const Icon = ICON_MAP[cat.iconName] || Sparkles;
            const isActive = activeCategoryId === cat.id;

            return (
              <button
                key={cat.id}
                onClick={() => {
                  playTapSound(600, 0.06);
                  onSelectCategory(cat.id);
                }}
                className={`flex-none inline-flex items-center gap-2 px-4 py-2.5 rounded-xl font-cairo font-bold text-xs sm:text-sm transition-all duration-200 cursor-pointer ${
                  isActive
                    ? isCafe
                      ? 'btn-legendary-gold text-black shadow-md shadow-yellow-500/30 scale-105'
                      : 'btn-legendary-crimson text-white shadow-md shadow-red-500/30 scale-105'
                    : 'bg-[#121218] border border-white/10 text-gray-300 hover:text-white hover:border-yellow-400/40 hover:bg-white/5'
                }`}
              >
                <Icon className="w-4 h-4 stroke-[2.2]" />
                <span className="whitespace-nowrap">{cat.title}</span>
                <span
                  className={`px-1.5 py-0.5 rounded-md text-[10px] font-black ${
                    isActive
                      ? isCafe
                        ? 'bg-black/20 text-black'
                        : 'bg-black/30 text-white'
                      : 'bg-white/10 text-gray-400'
                  }`}
                >
                  {cat.items.length}
                </span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
