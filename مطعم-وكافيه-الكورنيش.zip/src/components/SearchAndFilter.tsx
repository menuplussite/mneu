import React from 'react';
import { Search, X, Sparkles } from 'lucide-react';
import { playTapSound } from '../utils/audio';

interface SearchAndFilterProps {
  query: string;
  onQueryChange: (query: string) => void;
  resultCount: number;
  totalCount: number;
}

export const SearchAndFilter: React.FC<SearchAndFilterProps> = ({
  query,
  onQueryChange,
  resultCount,
  totalCount
}) => {
  return (
    <div className="relative max-w-2xl mx-auto mb-6 px-3">
      <div className="relative flex items-center bg-[#111116]/90 border border-white/15 rounded-2xl shadow-xl backdrop-blur-xl focus-within:border-yellow-400 focus-within:ring-1 focus-within:ring-yellow-400/50 transition-all">
        <div className="p-3.5 pr-4 text-yellow-400">
          <Search className="w-5 h-5 stroke-[2.2]" />
        </div>

        <input
          type="text"
          value={query}
          onChange={(e) => onQueryChange(e.target.value)}
          placeholder="ابحث عن صنف، مشروب، مشويات، أو قسم..."
          className="w-full bg-transparent border-0 outline-none text-white placeholder-gray-400 font-tajawal font-medium text-sm sm:text-base py-3 pl-10"
        />

        {query && (
          <button
            onClick={() => {
              playTapSound(400, 0.05);
              onQueryChange('');
            }}
            className="p-3 text-gray-400 hover:text-white transition-colors cursor-pointer"
            title="مسح البحث"
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      {query && (
        <div className="flex items-center justify-between text-xs text-gray-400 px-3 mt-2 font-medium">
          <div className="flex items-center gap-1">
            <Sparkles className="w-3.5 h-3.5 text-yellow-400" />
            <span>نتائج البحث عن: &ldquo;<strong className="text-yellow-400">{query}</strong>&rdquo;</span>
          </div>
          <div>
            وجدنا <span className="text-yellow-400 font-bold">{resultCount}</span> صنف
          </div>
        </div>
      )}
    </div>
  );
};
