import React from 'react';
import { MenuMode } from '../types';
import { Phone, MessageCircle, MapPin, Sparkles, Flame, Clock } from 'lucide-react';
import { RESTAURANT_PHONE, RESTAURANT_WHATSAPP } from '../data/menuData';
import { playTapSound } from '../utils/audio';

interface HeaderProps {
  mode: MenuMode;
  onOpenOffers: () => void;
  onReturnToSplash: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  mode,
  onOpenOffers,
  onReturnToSplash
}) => {
  const isCafe = mode === 'cafe';

  return (
    <header className="relative min-h-[300px] sm:min-h-[340px] flex items-center justify-center overflow-hidden border-b border-white/10">
      {/* Background with subtle zoom effect */}
      <div
        className="absolute inset-0 bg-cover bg-center opacity-25"
        style={{
          backgroundImage: `url('https://cdn.phototourl.com/free/2026-06-14-6a988a66-859b-4e93-99ef-c47b09573c97.jpg')`,
        }}
      />

      {/* Atmospheric dark overlays */}
      <div className="absolute inset-0 bg-gradient-to-t from-[#050507] via-black/60 to-black/80" />
      <div
        className={`absolute inset-0 transition-opacity duration-700 ${
          isCafe
            ? 'bg-[radial-gradient(circle_at_center,rgba(250,219,95,0.15)_0%,transparent_60%)]'
            : 'bg-[radial-gradient(circle_at_center,rgba(239,68,68,0.15)_0%,transparent_60%)]'
        }`}
      />

      {/* Top Navbar Row */}
      <div className="absolute top-4 inset-x-0 max-w-5xl mx-auto px-4 z-20 flex items-center justify-between">
        <button
          onClick={() => {
            playTapSound(500, 0.08);
            onReturnToSplash();
          }}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 backdrop-blur-md text-xs font-bold text-gray-200 border border-white/15 transition-all cursor-pointer"
        >
          <span>الشاشة الرئيسية</span>
        </button>

        <div className="flex items-center gap-2">
          <a
            href={`tel:${RESTAURANT_PHONE}`}
            onClick={() => playTapSound(600, 0.08)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-black/40 hover:bg-black/60 border border-yellow-400/40 text-yellow-400 text-xs font-bold transition-all shadow-md"
          >
            <Phone className="w-3.5 h-3.5" />
            <span dir="ltr">01043843865</span>
          </a>

          <a
            href={`https://wa.me/${RESTAURANT_WHATSAPP}`}
            target="_blank"
            rel="noopener noreferrer"
            onClick={() => playTapSound(700, 0.08)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#25D366]/20 hover:bg-[#25D366]/30 border border-[#25D366]/50 text-[#25D366] text-xs font-bold transition-all shadow-md"
          >
            <MessageCircle className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">واتساب</span>
          </a>
        </div>
      </div>

      {/* Main Header Hero Content */}
      <div className="relative z-10 text-center px-4 pt-12 pb-6 max-w-2xl mx-auto">
        {/* Status Chip */}
        <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-black/50 border border-white/10 text-xs text-gray-300 backdrop-blur-md mb-3 shadow-inner">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
          <span className="font-semibold text-emerald-400">مفتوح الآن لاستقبالكم</span>
          <span className="text-gray-500">•</span>
          <span className="flex items-center gap-1 text-gray-300">
            <MapPin className="w-3 h-3 text-red-400" />
            كورنيش النيل
          </span>
        </div>

        {/* Dynamic Mode Title with Neon Glow */}
        <h1
          id="main-title"
          className={`font-amiri text-5xl sm:text-7xl font-black leading-tight transition-all duration-500 ${
            isCafe
              ? 'text-yellow-400 animate-neon-cafe drop-shadow-[0_0_20px_rgba(250,219,95,0.7)]'
              : 'text-red-500 animate-neon-restaurant drop-shadow-[0_0_20px_rgba(239,68,68,0.7)]'
          }`}
        >
          {isCafe ? (
            <>
              كافيه
              <br />
              <span className="text-white">الكورنيش</span>
            </>
          ) : (
            <>
              مطعم
              <br />
              <span className="text-yellow-400">الكورنيش</span>
            </>
          )}
        </h1>

        <p className="mt-2 text-gray-300 text-xs sm:text-sm font-medium max-w-md mx-auto">
          {isCafe
            ? 'أجود أنواع القهوة المختصة، المشروبات الساخنة، العصائر الطبيعية والحلويات الشرقية والغربية'
            : 'أشهى المشويات على الفحم البلدي، الوجبات، الصواني العائلية وسندوتشات الكورنيش المخصوصة'}
        </p>

        {/* Sub-bar with quick highlights */}
        <div className="flex items-center justify-center gap-3 mt-4 flex-wrap">
          <span className="inline-flex items-center gap-1.5 text-xs text-yellow-300/90 font-semibold bg-yellow-500/10 px-3 py-1 rounded-lg border border-yellow-500/20">
            <Clock className="w-3.5 h-3.5 text-yellow-400" />
            {isCafe ? 'مواعيد الكافيه: 9:00 ص - 2:00 ص' : 'مواعيد المطعم: 2:00 م - 1:00 ص'}
          </span>

          <button
            onClick={() => {
              playTapSound(650, 0.09);
              onOpenOffers();
            }}
            className="inline-flex items-center gap-1.5 text-xs text-white font-bold bg-gradient-to-r from-red-600 to-amber-600 px-3 py-1 rounded-lg border border-yellow-400/40 hover:scale-105 active:scale-95 transition-all cursor-pointer shadow-md"
          >
            <Flame className="w-3.5 h-3.5 text-yellow-300" />
            <span>عروض الافتتاح</span>
          </button>
        </div>
      </div>
    </header>
  );
};
