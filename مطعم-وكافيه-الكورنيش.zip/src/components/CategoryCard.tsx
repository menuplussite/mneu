import React, { useState } from 'react';
import { MenuCategory, MenuItem, MenuMode, PricePortion } from '../types';
import {
  Coffee,
  Flame,
  GlassWater,
  Sparkles,
  Utensils,
  Wine,
  IceCream,
  Cookie,
  Star,
  Crown,
  Beef,
  PlusCircle,
  ChevronDown,
  ChevronUp,
  Info,
  Plus,
  Check,
  LucideIcon
} from 'lucide-react';
import { playTapSound, playSuccessSound } from '../utils/audio';

const ICON_MAP: Record<string, LucideIcon> = {
  Coffee,
  Flame,
  GlassWater,
  Sparkles,
  Utensils,
  Wine,
  IceCream,
  Cookie,
  Star,
  Crown,
  Beef,
  PlusCircle
};

interface CategoryCardProps {
  category: MenuCategory;
  mode: MenuMode;
  searchQuery?: string;
  defaultOpen?: boolean;
  onAddToCart: (item: MenuItem, portion?: PricePortion) => void;
}

export const CategoryCard: React.FC<CategoryCardProps> = ({
  category,
  mode,
  searchQuery = '',
  defaultOpen = false,
  onAddToCart
}) => {
  const [isOpen, setIsOpen] = useState(defaultOpen || !!searchQuery);
  const [addedItemKey, setAddedItemKey] = useState<string | null>(null);

  // If search query is active and changes, expand matching cards
  React.useEffect(() => {
    if (searchQuery) {
      setIsOpen(true);
    }
  }, [searchQuery]);

  const isCafe = mode === 'cafe';
  const Icon = ICON_MAP[category.iconName] || Sparkles;

  // Filter items if searching
  const displayedItems = searchQuery
    ? category.items.filter((item) => {
        const text = `${item.name} ${item.description || ''} ${category.title} ${
          typeof item.price === 'number' ? item.price : ''
        }`.toLowerCase();
        return text.includes(searchQuery.toLowerCase());
      })
    : category.items;

  if (displayedItems.length === 0) return null;

  const handleAddItem = (item: MenuItem, portion?: PricePortion) => {
    playSuccessSound();
    onAddToCart(item, portion);
    const key = `${item.id}-${portion ? portion.portion : 'default'}`;
    setAddedItemKey(key);
    setTimeout(() => {
      setAddedItemKey((prev) => (prev === key ? null : prev));
    }, 1200);
  };

  return (
    <section id={category.id} className="scroll-mt-24 mb-6">
      {/* LED Neon Glowing Frame */}
      <div className={`led-frame ${!isCafe ? 'led-frame-red' : ''} shadow-2xl`}>
        <div className="relative w-full rounded-[1.65rem] bg-[#101015] overflow-hidden border border-white/10">
          {/* FRONT HEADER / HERO COVER */}
          <div
            onClick={() => {
              playTapSound(550, 0.08);
              setIsOpen(!isOpen);
            }}
            className="relative min-h-[170px] sm:min-h-[220px] cursor-pointer overflow-hidden group select-none"
          >
            {/* Background image with hover zoom */}
            <div
              className="absolute inset-0 bg-cover bg-center transition-transform duration-700 group-hover:scale-105"
              style={{ backgroundImage: `url('${category.img}')` }}
            />

            {/* Gradient Overlays for High Legibility */}
            <div className="absolute inset-0 bg-gradient-to-t from-[#101015] via-[#101015]/75 to-transparent" />
            <div className="absolute inset-0 bg-gradient-to-r from-[#101015]/90 via-[#101015]/50 to-transparent" />

            {/* Header Content */}
            <div className="relative z-10 p-5 sm:p-7 flex items-center justify-between min-h-[170px] sm:min-h-[220px]">
              <div className="flex items-center gap-4 sm:gap-6">
                {/* Glowing Icon Container */}
                <div
                  className={`w-16 h-16 sm:w-20 sm:h-20 rounded-2xl flex items-center justify-center shadow-2xl transition-transform group-hover:scale-110 ${
                    isCafe
                      ? 'bg-gradient-to-br from-[#FFF5B0] to-[#D4A017] text-black shadow-yellow-500/30'
                      : 'bg-gradient-to-br from-[#fca5a5] to-[#dc2626] text-white shadow-red-500/30'
                  }`}
                >
                  <Icon className="w-8 h-8 sm:w-10 sm:h-10 stroke-[2.2]" />
                </div>

                {/* Title & Stats */}
                <div>
                  <h2 className="font-amiri font-bold text-2xl sm:text-4xl text-white drop-shadow-[0_2px_10px_rgba(0,0,0,0.8)]">
                    {category.title}
                  </h2>
                  <div className="flex items-center gap-2 mt-1.5">
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-bold bg-white/10 text-yellow-300 border border-yellow-400/20">
                      {displayedItems.length} {displayedItems.length === 1 ? 'صنف' : 'أصناف'}
                    </span>
                    <span className="text-xs text-gray-400 font-medium">
                      {isOpen ? 'انقر للإغلاق' : 'انقر لعرض الأصناف والأسعار'}
                    </span>
                  </div>
                </div>
              </div>

              {/* Expand/Collapse Toggle Button */}
              <div
                className={`w-11 h-11 rounded-xl flex items-center justify-center border transition-all ${
                  isOpen
                    ? isCafe
                      ? 'bg-yellow-400 text-black border-yellow-400 shadow-lg shadow-yellow-500/30'
                      : 'bg-red-600 text-white border-red-500 shadow-lg shadow-red-500/30'
                    : 'bg-black/50 text-gray-300 border-white/20 group-hover:border-yellow-400 group-hover:text-yellow-400'
                }`}
              >
                {isOpen ? <ChevronUp className="w-6 h-6" /> : <ChevronDown className="w-6 h-6" />}
              </div>
            </div>
          </div>

          {/* OPEN CONTENT: ITEMS LIST */}
          {isOpen && (
            <div className="border-t border-white/10 bg-[#0d0d12]/95 backdrop-blur-md animate-fadeIn">
              {/* Optional Category Note */}
              {category.note && (
                <div className="p-4 sm:p-5 pb-0">
                  <div className="flex items-center gap-2.5 p-3 rounded-xl bg-yellow-500/10 border border-yellow-400/25 text-yellow-300 text-xs sm:text-sm font-bold">
                    <Info className="w-4 h-4 text-yellow-400 flex-none" />
                    <span>{category.note}</span>
                  </div>
                </div>
              )}

              {/* Items Grid */}
              <div className="p-3 sm:p-5 space-y-3">
                {displayedItems.map((item) => {
                  const isMultiPortion = Array.isArray(item.price);

                  return (
                    <div
                      key={item.id}
                      className="group/item flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3.5 rounded-2xl bg-white/[0.03] hover:bg-white/[0.07] border border-white/[0.06] hover:border-yellow-400/30 transition-all duration-200"
                    >
                      {/* Item Details */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="w-1.5 h-1.5 rounded-full bg-yellow-400" />
                          <h3 className="font-cairo font-black text-base text-white group-hover/item:text-yellow-300 transition-colors">
                            {item.name}
                          </h3>
                        </div>

                        {item.description && (
                          <p className="text-xs text-gray-300 font-medium mt-1 pr-3.5 leading-relaxed">
                            {item.description}
                          </p>
                        )}
                      </div>

                      {/* Item Pricing and Actions */}
                      <div className="flex items-center justify-between sm:justify-end gap-2.5 flex-wrap pt-2 sm:pt-0 border-t sm:border-t-0 border-white/5">
                        {/* Multi-portion pricing buttons */}
                        {isMultiPortion ? (
                          <div className="flex flex-wrap gap-1.5 items-center">
                            {(item.price as PricePortion[]).map((portion, pIdx) => {
                              const key = `${item.id}-${portion.portion}`;
                              const isAdded = addedItemKey === key;

                              return (
                                <button
                                  key={pIdx}
                                  onClick={() => handleAddItem(item, portion)}
                                  className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-bold transition-all cursor-pointer ${
                                    isAdded
                                      ? 'bg-emerald-500 text-white border-emerald-400 shadow-md shadow-emerald-500/30'
                                      : 'bg-[#181822] hover:bg-yellow-500/20 border-yellow-400/30 text-gray-200 hover:border-yellow-400 hover:text-white'
                                  }`}
                                  title={`إضافة ${portion.portion} للسلة`}
                                >
                                  {isAdded ? (
                                    <Check className="w-3.5 h-3.5 text-white" />
                                  ) : (
                                    <Plus className="w-3 h-3 text-yellow-400" />
                                  )}
                                  <span className="text-gray-300">{portion.portion}:</span>
                                  <span className="text-yellow-400 font-cairo font-black">
                                    {portion.price} ج
                                  </span>
                                </button>
                              );
                            })}
                          </div>
                        ) : (
                          /* Single price + Add to Cart button */
                          <div className="flex items-center gap-2">
                            <div className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-[#FADB5F] to-[#D4A017] text-black font-cairo font-black text-sm shadow-md">
                              {item.price} ج
                            </div>

                            <button
                              onClick={() => handleAddItem(item)}
                              className={`p-2 rounded-xl transition-all cursor-pointer flex items-center justify-center ${
                                addedItemKey === `${item.id}-default`
                                  ? 'bg-emerald-500 text-white shadow-lg shadow-emerald-500/30'
                                  : isCafe
                                  ? 'bg-yellow-400/20 hover:bg-yellow-400 text-yellow-300 hover:text-black border border-yellow-400/40'
                                  : 'bg-red-600/20 hover:bg-red-600 text-red-300 hover:text-white border border-red-500/40'
                              }`}
                              title="إضافة للطلب"
                            >
                              {addedItemKey === `${item.id}-default` ? (
                                <Check className="w-4 h-4" />
                              ) : (
                                <Plus className="w-4 h-4 stroke-[2.5]" />
                              )}
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
};
