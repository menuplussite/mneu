import React from 'react';
import { MenuMode } from '../types';
import { Coffee, Utensils, Sparkles } from 'lucide-react';
import { playTapSound } from '../utils/audio';

interface ModeTabsProps {
  currentMode: MenuMode;
  onSwitchMode: (mode: MenuMode) => void;
}

export const ModeTabs: React.FC<ModeTabsProps> = ({ currentMode, onSwitchMode }) => {
  const isCafe = currentMode === 'cafe';

  return (
    <div className="relative z-10 max-w-xl mx-auto my-6 px-3">
      <div className="grid grid-cols-2 p-1.5 rounded-2xl bg-[#101015]/90 border border-white/10 backdrop-blur-xl shadow-2xl">
        {/* Cafe Tab */}
        <button
          onClick={() => {
            playTapSound(600, 0.09);
            onSwitchMode('cafe');
          }}
          className={`relative flex items-center justify-center gap-2.5 py-3.5 px-4 rounded-xl font-cairo font-black text-base sm:text-lg transition-all duration-300 cursor-pointer ${
            isCafe
              ? 'btn-legendary-gold text-black shadow-lg shadow-yellow-500/25 scale-[1.02]'
              : 'text-gray-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <Coffee className={`w-5 h-5 ${isCafe ? 'text-black stroke-[2.5]' : 'text-yellow-400'}`} />
          <span>كافيه الكورنيش</span>
          {isCafe && (
            <span className="absolute -top-1.5 -right-1.5 flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-yellow-400 opacity-75" />
              <span className="relative inline-flex rounded-full h-3 w-3 bg-yellow-500" />
            </span>
          )}
        </button>

        {/* Restaurant Tab */}
        <button
          onClick={() => {
            playTapSound(700, 0.09);
            onSwitchMode('restaurant');
          }}
          className={`relative flex items-center justify-center gap-2.5 py-3.5 px-4 rounded-xl font-cairo font-black text-base sm:text-lg transition-all duration-300 cursor-pointer ${
            !isCafe
              ? 'btn-legendary-crimson text-white shadow-lg shadow-red-600/35 scale-[1.02]'
              : 'text-gray-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <Utensils className={`w-5 h-5 ${!isCafe ? 'text-white stroke-[2.5]' : 'text-red-400'}`} />
          <span>مطعم الكورنيش</span>
          {!isCafe && (
            <span className="absolute -top-1.5 -right-1.5 flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75" />
              <span className="relative inline-flex rounded-full h-3 w-3 bg-red-500" />
            </span>
          )}
        </button>
      </div>
    </div>
  );
};
