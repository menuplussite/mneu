import React, { useState } from 'react';
import { X, Trash2, Plus, Minus, MessageCircle, Phone, ShoppingBag, Bike, UtensilsCrossed } from 'lucide-react';
import { CartItem } from '../types';
import { RESTAURANT_PHONE, RESTAURANT_WHATSAPP } from '../data/menuData';
import { playTapSound, playSuccessSound } from '../utils/audio';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onUpdateQuantity: (id: string, delta: number) => void;
  onRemoveItem: (id: string) => void;
  onClearCart: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  items,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart
}) => {
  const [orderType, setOrderType] = useState<'delivery' | 'dinein'>('delivery');
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [addressOrTable, setAddressOrTable] = useState('');
  const [notes, setNotes] = useState('');

  if (!isOpen) return null;

  const totalAmount = items.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const totalCount = items.reduce((sum, item) => sum + item.quantity, 0);

  const handleSendWhatsApp = () => {
    playSuccessSound();
    let message = `*طلب جديد من منيو مطعم وكافيه الكورنيش*\n`;
    message += `---------------------------------\n`;
    message += `*نوع الطلب:* ${orderType === 'delivery' ? '🛵 توصيل منازل (ديليفري)' : '🍽️ داخل المطعم / الكافيه'}\n`;
    if (customerName) message += `*الاسم:* ${customerName}\n`;
    if (customerPhone) message += `*رقم الهاتف:* ${customerPhone}\n`;
    if (addressOrTable) {
      message += `*${orderType === 'delivery' ? 'العنوان' : 'رقم الطاولة'}:* ${addressOrTable}\n`;
    }
    message += `---------------------------------\n`;
    message += `*تفاصيل الطلب:*\n`;

    items.forEach((item, index) => {
      const portion = item.portionLabel ? ` (${item.portionLabel})` : '';
      message += `${index + 1}. ${item.name}${portion} × ${item.quantity} = ${item.price * item.quantity} ج\n`;
    });

    message += `---------------------------------\n`;
    message += `*الإجمالي:* ${totalAmount} جنيه مصري\n`;
    if (notes) message += `*ملاحظات إضافية:* ${notes}\n`;

    const encoded = encodeURIComponent(message);
    window.open(`https://wa.me/${RESTAURANT_WHATSAPP}?text=${encoded}`, '_blank');
  };

  return (
    <div
      className="fixed inset-0 z-50 flex justify-end bg-black/80 backdrop-blur-sm animate-fadeIn"
      onClick={(e) => {
        if (e.target === e.currentTarget) {
          playTapSound(400, 0.05);
          onClose();
        }
      }}
    >
      <div className="relative w-full max-w-md h-full bg-[#101016] border-r border-white/10 shadow-2xl flex flex-col overflow-hidden animate-slideLeft">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-white/10 flex items-center justify-between bg-[#15151e]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-yellow-400 text-black flex items-center justify-center font-bold shadow-md shadow-yellow-500/20">
              <ShoppingBag className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-cairo font-black text-lg text-white">سلة الطلبات</h2>
              <p className="text-xs text-gray-400">
                {totalCount} {totalCount === 1 ? 'صنف مختار' : 'أصناف مختارة'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {items.length > 0 && (
              <button
                onClick={() => {
                  playTapSound(400, 0.08);
                  onClearCart();
                }}
                className="p-2 rounded-lg text-red-400 hover:bg-red-500/10 text-xs font-bold transition-all cursor-pointer"
                title="تفريغ السلة"
              >
                مسح الكل
              </button>
            )}
            <button
              onClick={() => {
                playTapSound(400, 0.05);
                onClose();
              }}
              className="p-2 rounded-xl bg-white/5 hover:bg-white/15 text-gray-300 hover:text-white transition-all cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Items List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3 divide-y divide-white/5">
          {items.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-6 text-gray-400">
              <div className="w-16 h-16 rounded-full bg-white/5 flex items-center justify-center text-yellow-400 mb-3 border border-white/10">
                <ShoppingBag className="w-8 h-8 opacity-70" />
              </div>
              <h3 className="font-cairo font-bold text-base text-white">السلة فارغة حالياً</h3>
              <p className="text-xs text-gray-400 mt-1 max-w-xs">
                تصفح قائمة الكافيه والمطعم واضغط على علامة (+) بجوار أي صنف لإضافته مباشرة للطلب
              </p>
            </div>
          ) : (
            items.map((item) => (
              <div key={item.id} className="pt-3 first:pt-0 flex items-center justify-between gap-3">
                <div className="flex-1 min-w-0">
                  <div className="font-cairo font-bold text-sm text-white truncate">
                    {item.name}
                  </div>
                  {item.portionLabel && (
                    <div className="text-xs text-yellow-400/90 font-medium">
                      الحجم / الكمية: {item.portionLabel}
                    </div>
                  )}
                  <div className="text-xs text-gray-400 font-semibold mt-0.5">
                    {item.price} ج × {item.quantity} ={' '}
                    <span className="text-yellow-400 font-bold">{item.price * item.quantity} ج</span>
                  </div>
                </div>

                {/* Quantity Controls */}
                <div className="flex items-center gap-1.5 bg-[#181824] p-1 rounded-xl border border-white/10">
                  <button
                    onClick={() => {
                      playTapSound(500, 0.05);
                      onUpdateQuantity(item.id, -1);
                    }}
                    className="w-7 h-7 rounded-lg bg-white/5 hover:bg-white/20 text-gray-300 flex items-center justify-center transition-all cursor-pointer"
                  >
                    <Minus className="w-3.5 h-3.5" />
                  </button>

                  <span className="w-6 text-center font-cairo font-black text-xs text-white">
                    {item.quantity}
                  </span>

                  <button
                    onClick={() => {
                      playTapSound(650, 0.05);
                      onUpdateQuantity(item.id, 1);
                    }}
                    className="w-7 h-7 rounded-lg bg-yellow-400/20 hover:bg-yellow-400 hover:text-black text-yellow-300 flex items-center justify-center transition-all cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* Delete button */}
                <button
                  onClick={() => {
                    playTapSound(400, 0.05);
                    onRemoveItem(item.id);
                  }}
                  className="text-gray-500 hover:text-red-400 p-1.5 transition-colors cursor-pointer"
                  title="حذف"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))
          )}
        </div>

        {/* Customer Information and Order Mode */}
        {items.length > 0 && (
          <div className="p-4 border-t border-white/10 bg-[#14141e] space-y-3">
            {/* Delivery or Dine-in Switch */}
            <div className="grid grid-cols-2 gap-2 p-1 rounded-xl bg-black/40 border border-white/10">
              <button
                onClick={() => setOrderType('delivery')}
                className={`flex items-center justify-center gap-2 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  orderType === 'delivery'
                    ? 'bg-yellow-400 text-black shadow-md'
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                <Bike className="w-3.5 h-3.5" />
                <span>توصيل ديليفري</span>
              </button>

              <button
                onClick={() => setOrderType('dinein')}
                className={`flex items-center justify-center gap-2 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  orderType === 'dinein'
                    ? 'bg-red-600 text-white shadow-md'
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                <UtensilsCrossed className="w-3.5 h-3.5" />
                <span>تناول بالصالة</span>
              </button>
            </div>

            {/* Form Inputs */}
            <div className="space-y-2 text-xs">
              <div className="grid grid-cols-2 gap-2">
                <input
                  type="text"
                  placeholder="الاسم الكريم"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  className="w-full bg-[#1c1c28] border border-white/10 rounded-xl p-2.5 text-white placeholder-gray-500 outline-none focus:border-yellow-400"
                />
                <input
                  type="tel"
                  placeholder="رقم الهاتف"
                  value={customerPhone}
                  onChange={(e) => setCustomerPhone(e.target.value)}
                  className="w-full bg-[#1c1c28] border border-white/10 rounded-xl p-2.5 text-white placeholder-gray-500 outline-none focus:border-yellow-400"
                />
              </div>

              <input
                type="text"
                placeholder={orderType === 'delivery' ? 'العنوان بالتفصيل لتوصيل الطلب' : 'رقم الطاولة في الصالة'}
                value={addressOrTable}
                onChange={(e) => setAddressOrTable(e.target.value)}
                className="w-full bg-[#1c1c28] border border-white/10 rounded-xl p-2.5 text-white placeholder-gray-500 outline-none focus:border-yellow-400"
              />

              <input
                type="text"
                placeholder="ملاحظات (مثال: بدون سكر، تسوية زيادة، شطة خفيفة)"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="w-full bg-[#1c1c28] border border-white/10 rounded-xl p-2.5 text-white placeholder-gray-500 outline-none focus:border-yellow-400"
              />
            </div>

            {/* Total Summary */}
            <div className="pt-2 flex items-center justify-between border-t border-white/10">
              <span className="text-gray-300 font-bold text-sm">إجمالي الحساب:</span>
              <span className="font-cairo font-black text-2xl text-yellow-400 drop-shadow">
                {totalAmount} جنيه
              </span>
            </div>

            {/* WhatsApp Send Button */}
            <button
              onClick={handleSendWhatsApp}
              className="w-full py-3.5 px-4 rounded-2xl bg-[#25D366] hover:bg-[#20bd5a] text-white font-cairo font-black text-base flex items-center justify-center gap-2 shadow-xl shadow-green-600/30 transition-all cursor-pointer hover:scale-[1.02] active:scale-[0.98]"
            >
              <MessageCircle className="w-5 h-5 fill-current" />
              <span>إرسال الطلب فوراً عبر واتساب</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
