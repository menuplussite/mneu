import React, { useState, useEffect, useMemo } from 'react';
import { MenuMode, MenuItem, PricePortion, CartItem, SpecialOffer } from './types';
import { CAFE_DATA, RESTAURANT_DATA } from './data/menuData';
import { SplashScreen } from './components/SplashScreen';
import { Header } from './components/Header';
import { ModeTabs } from './components/ModeTabs';
import { CategoryChips } from './components/CategoryChips';
import { CategoryCard } from './components/CategoryCard';
import { SearchAndFilter } from './components/SearchAndFilter';
import { OffersModal } from './components/OffersModal';
import { CartDrawer } from './components/CartDrawer';
import { FloatingActions } from './components/FloatingActions';
import { Footer } from './components/Footer';
import { Flame, Tags, SearchX } from 'lucide-react';
import { playTapSound, playSuccessSound, getIsMuted } from './utils/audio';

export default function App() {
  const [showSplash, setShowSplash] = useState(true);
  const [mode, setMode] = useState<MenuMode>('cafe');
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategoryId, setActiveCategoryId] = useState<string | null>(null);
  const [offersModalOpen, setOffersModalOpen] = useState(false);
  const [cartOpen, setCartOpen] = useState(false);
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [isMuted, setIsMuted] = useState(getIsMuted());

  // Current active categories depending on mode
  const currentCategories = useMemo(() => {
    return mode === 'cafe' ? CAFE_DATA : RESTAURANT_DATA;
  }, [mode]);

  // Total items count across categories
  const totalItemsCount = useMemo(() => {
    return currentCategories.reduce((acc, cat) => acc + cat.items.length, 0);
  }, [currentCategories]);

  // Filtered categories and total matches
  const { filteredCategories, matchingItemsCount } = useMemo(() => {
    if (!searchQuery.trim()) {
      return {
        filteredCategories: currentCategories,
        matchingItemsCount: totalItemsCount
      };
    }

    const q = searchQuery.toLowerCase().trim();
    let count = 0;

    const filtered = currentCategories
      .map((cat) => {
        const matchingItems = cat.items.filter((item) => {
          const text = `${item.name} ${item.description || ''} ${cat.title} ${
            typeof item.price === 'number' ? item.price : ''
          }`.toLowerCase();
          return text.includes(q);
        });

        count += matchingItems.length;

        return {
          ...cat,
          items: matchingItems
        };
      })
      .filter((cat) => cat.items.length > 0);

    return {
      filteredCategories: filtered,
      matchingItemsCount: count
    };
  }, [currentCategories, searchQuery, totalItemsCount]);

  // Set initial category when mode changes
  useEffect(() => {
    if (currentCategories.length > 0) {
      setActiveCategoryId(currentCategories[0].id);
    }
  }, [currentCategories]);

  // Handle Browser Back Button (popstate)
  useEffect(() => {
    const handlePopState = () => {
      if (offersModalOpen) {
        setOffersModalOpen(false);
        return;
      }
      if (cartOpen) {
        setCartOpen(false);
        return;
      }
      setShowSplash(true);
    };

    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, [offersModalOpen, cartOpen]);

  // Enter from splash screen
  const handleEnterFromSplash = (selectedMode: MenuMode) => {
    setMode(selectedMode);
    setShowSplash(false);
    window.history.pushState({ view: 'menu' }, '', '#menu');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Switch mode between cafe and restaurant
  const handleSwitchMode = (newMode: MenuMode) => {
    setMode(newMode);
    setSearchQuery('');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Scroll to category
  const handleSelectCategory = (categoryId: string) => {
    setActiveCategoryId(categoryId);
    const element = document.getElementById(categoryId);
    if (element) {
      const topOffset = element.getBoundingClientRect().top + window.pageYOffset - 85;
      window.scrollTo({ top: topOffset, behavior: 'smooth' });
    }
  };

  // Add standard menu item to cart
  const handleAddToCart = (item: MenuItem, portion?: PricePortion) => {
    const itemId = portion ? `${item.id}-${portion.portion}` : item.id;
    const price = portion
      ? portion.price
      : typeof item.price === 'number'
      ? item.price
      : typeof item.price === 'string'
      ? parseFloat(item.price) || 0
      : (item.price as PricePortion[])[0]?.price || 0;

    const portionLabel = portion ? portion.portion : undefined;

    setCartItems((prev) => {
      const existing = prev.find((ci) => ci.id === itemId);
      if (existing) {
        return prev.map((ci) =>
          ci.id === itemId ? { ...ci, quantity: ci.quantity + 1 } : ci
        );
      }
      return [
        ...prev,
        {
          id: itemId,
          name: item.name,
          portionLabel,
          price,
          quantity: 1,
          categoryTitle: mode === 'cafe' ? 'الكافيه' : 'المطعم'
        }
      ];
    });
  };

  // Add special offer to cart
  const handleAddOfferToCart = (offer: SpecialOffer) => {
    setCartItems((prev) => {
      const existing = prev.find((ci) => ci.id === offer.id);
      if (existing) {
        return prev.map((ci) =>
          ci.id === offer.id ? { ...ci, quantity: ci.quantity + 1 } : ci
        );
      }
      return [
        ...prev,
        {
          id: offer.id,
          name: offer.title,
          portionLabel: 'عرض خاص',
          price: offer.price,
          quantity: 1,
          categoryTitle: 'عروض الافتتاح'
        }
      ];
    });
    setOffersModalOpen(false);
    setCartOpen(true);
  };

  // Update quantity in cart
  const handleUpdateCartQuantity = (id: string, delta: number) => {
    setCartItems((prev) =>
      prev
        .map((item) => {
          if (item.id === id) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter(Boolean) as CartItem[]
    );
  };

  // Remove item from cart
  const handleRemoveCartItem = (id: string) => {
    setCartItems((prev) => prev.filter((item) => item.id !== id));
  };

  // Clear entire cart
  const handleClearCart = () => {
    setCartItems([]);
  };

  const cartTotal = useMemo(() => {
    return cartItems.reduce((acc, ci) => acc + ci.price * ci.quantity, 0);
  }, [cartItems]);

  const cartCount = useMemo(() => {
    return cartItems.reduce((acc, ci) => acc + ci.quantity, 0);
  }, [cartItems]);

  return (
    <div className="min-h-screen bg-[#050507] text-white flex flex-col selection:bg-[#FADB5F] selection:text-black">
      {/* Splash Screen */}
      {showSplash && (
        <SplashScreen
          onEnter={handleEnterFromSplash}
          onOpenOffers={() => setOffersModalOpen(true)}
          isMuted={isMuted}
          onToggleSound={() => setIsMuted(getIsMuted())}
        />
      )}

      {/* Main App Bar & Hero Header */}
      <Header
        mode={mode}
        onOpenOffers={() => setOffersModalOpen(true)}
        onReturnToSplash={() => {
          setShowSplash(true);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-5xl w-full mx-auto px-3 sm:px-6 py-4">
        {/* Mode Segmented Controls (Cafe / Restaurant) */}
        <ModeTabs currentMode={mode} onSwitchMode={handleSwitchMode} />

        {/* Grand Opening Offers Banner */}
        <div className="max-w-2xl mx-auto mb-6 px-3">
          <button
            onClick={() => {
              playTapSound(750, 0.1);
              setOffersModalOpen(true);
            }}
            className="btn-legendary-offers animate-super-pulse w-full py-3.5 px-4 rounded-2xl flex items-center justify-between text-white shadow-xl cursor-pointer"
          >
            <div className="flex items-center gap-2.5">
              <Flame className="w-6 h-6 text-yellow-300 animate-pulse" />
              <div className="text-right">
                <span className="font-cairo font-black text-lg sm:text-xl text-white block">
                  عروووووض الافتتاح الكبرى 🔥
                </span>
                <span className="text-xs text-yellow-300 font-bold block">
                  صواني التوفير الملكية + هدية حلو + توصيل مجاني
                </span>
              </div>
            </div>
            <div className="px-3 py-1 rounded-xl bg-black/40 border border-yellow-400/40 text-yellow-300 text-xs font-black flex items-center gap-1">
              <Tags className="w-3.5 h-3.5" />
              <span>شاهد العروض</span>
            </div>
          </button>
        </div>

        {/* Live Search & Filter Bar */}
        <SearchAndFilter
          query={searchQuery}
          onQueryChange={setSearchQuery}
          resultCount={matchingItemsCount}
          totalCount={totalItemsCount}
        />

        {/* Sticky Category Navigation Chips */}
        <CategoryChips
          categories={currentCategories}
          activeCategoryId={activeCategoryId}
          onSelectCategory={handleSelectCategory}
          mode={mode}
        />

        {/* Menu Items Categories List */}
        {filteredCategories.length > 0 ? (
          <div className="space-y-6">
            {filteredCategories.map((category) => (
              <CategoryCard
                key={category.id}
                category={category}
                mode={mode}
                searchQuery={searchQuery}
                defaultOpen={filteredCategories.length === 1 || !!searchQuery}
                onAddToCart={handleAddToCart}
              />
            ))}
          </div>
        ) : (
          /* Empty Search Results */
          <div className="text-center py-16 px-4 bg-[#111116] border border-white/10 rounded-3xl max-w-md mx-auto my-8">
            <div className="w-16 h-16 rounded-2xl bg-yellow-400/10 text-yellow-400 flex items-center justify-center mx-auto mb-4 border border-yellow-400/20">
              <SearchX className="w-8 h-8" />
            </div>
            <h3 className="font-cairo font-black text-xl text-white">لم نجد نتائج مطابقة</h3>
            <p className="text-gray-400 text-sm mt-1.5 mb-6 leading-relaxed">
              جرّب البحث باسم صنف آخر أو تصفح القائمة الكاملة
            </p>
            <button
              onClick={() => {
                playSuccessSound();
                setSearchQuery('');
              }}
              className="btn-legendary-gold px-6 py-2.5 rounded-xl font-cairo font-black text-sm text-black cursor-pointer shadow-lg"
            >
              عرض المنيو كاملة
            </button>
          </div>
        )}
      </main>

      {/* Floating Action Controls */}
      <FloatingActions
        cartCount={cartCount}
        cartTotal={cartTotal}
        onOpenCart={() => setCartOpen(true)}
        isMuted={isMuted}
        onToggleSound={() => {
          setIsMuted(getIsMuted());
        }}
      />

      {/* Offers Modal */}
      <OffersModal
        isOpen={offersModalOpen}
        onClose={() => setOffersModalOpen(false)}
        onAddToCart={handleAddOfferToCart}
      />

      {/* Cart Drawer */}
      <CartDrawer
        isOpen={cartOpen}
        onClose={() => setCartOpen(false)}
        items={cartItems}
        onUpdateQuantity={handleUpdateCartQuantity}
        onRemoveItem={handleRemoveCartItem}
        onClearCart={handleClearCart}
      />

      {/* Footer */}
      <Footer />
    </div>
  );
}
